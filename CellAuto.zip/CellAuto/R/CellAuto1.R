# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

library(R6)
library(gtools)

CA <- R6Class(
  "CA",
  public = list(
    decimal = NULL,
    binary = NULL,
    alpha = NULL,
    ms = NULL,
    mms = NULL,
    nrows = NULL,
    ncols = NULL,

    initialize = function(decimal = NA, alpha = c(0,1), ms = c(-1,0,1)) {
      self$decimal = decimal
      self$alpha = alpha
      self$ms = ms
      self$ncols = length(ms)
      self$nrows = length(alpha)^self$ncols
      self$binary = self$dectobase()
      self$mms = self$Minimal_Memory_Set()
    },

    CABin = function(binary = NA) {
      self$binary = binary
      self$decimal = self$basetodec()
      self$mms = self$Minimal_Memory_Set()
    },

    CAIden = function(){
      binary = self$Table_Not_Rule()[,"0"]
      self$binary = binary
      self$decimal = self$basetodec()
      self$mms = self$Minimal_Memory_Set()
    },

    CAPattern = function(pattern=NA){
      self$CAIden()
      table=self$Table_Not_Rule()
      l=self$ncols
      k=self$nrows
      A=length(self$alpha)
      for (i in 1:k){
        if (sum(table[i,]==pattern)==l) self$binary[i]=(self$binary[i]+1)%%A
      }
      self$decimal = self$basetodec()
      self$mms = self$Minimal_Memory_Set()
    },

    CAnPattern = function (patterns = NA){
      if (!is.matrix(patterns)) patterns = matrix(patterns,ncol=length(patterns),nrow = 1)
      n=nrow(patterns)
      self$CAIden()
      table=self$Table_Not_Rule()
      l=self$ncols
      k=self$nrows
      A=length(self$alpha)
      for (i in 1:k){
        for (j in 1:n){
          if (sum(table[i,]==patterns[j,])==l) self$binary[i]=(self$binary[i] + 1)%%A
        }
      }
      self$decimal = self$basetodec()
      self$mms = self$Minimal_Memory_Set()
    },

    CAModify = function(pos=NA,val=NA) {
      self$binary[pos]=val
      self$decimal = self$basetodec()
      self$mms = self$Minimal_Memory_Set()
    },

    NumPatterns = function (){
      table=self$Table_Not_Rule()
      if (sum(self$mms=="0")==0) {
        k1=length(self$alpha)
        k2=length(self$mms)
        numpat=k1^k2
      }
      else numpat=sum(table[,"0"]!=self$binary)
      return (numpat)
    },

    CAMatrix = function(M = NA){
      if (ncol(M)>1){
        self$ncols = ncol(M) - 1
        self$nrows = nrow(M)
        self$binary = M[, ncol(M)]
        self$decimal = self$basetodec()
        self$alpha = sort(unique(as.numeric(M)))
        self$ms = colnames(M)[1:self$ncols]
        self$mms = self$Minimal_Memory_Set()
      }
    },

    dectobase = function(){
      Base=length(self$alpha)
      vec = rep(0,self$nrows)
      i = 1
      Y = self$decimal
      while (Y>0){
        vec[self$nrows-i+1] = Y%%Base
        i = i + 1
        Y = Y %/% Base
      }
      return(vec)
    },

    basetodec = function(){
      acu = 0
      n = length(self$binary)
      Base = length(self$alpha)
      for (i in 1:self$nrows){
        acu = acu + Base^(n-i)%*%self$binary[i]
      }
      return (acu)
    },

    Table_Not_Rule = function (){
      table = matrix(-1,self$nrows,self$ncols)
      Base = length(self$alpha)
      w=self$nrows/Base
      for (j in 1:self$ncols){
        aux=rep(Base-1,w)
        for (i in seq(Base-2,0,-1)){
          aux=c(aux,rep(i,w))
        }
        table[,j]=aux
        w=w/Base
      }
      row.names(table)=seq(1,self$nrows,1)
      colnames(table)=self$ms
      return (table)
    },

    Table_Rule = function (){
      table = cbind(self$Table_Not_Rule(),self$binary)
      row.names(table)=seq(1,self$nrows,1)
      colnames(table)[1:self$ncols]=self$ms
      return(table)
    },


    Minimal_Memory_Set = function() {
      k3 = length(self$ms)
      k2 = length(self$alpha)
      ms1=""
      for (j in 1:k3){
        esen = F
        for (i in seq(1,k2^(j-1),1)){
          y=k2^(k3-j)
          for (i2 in seq(1,y,1)){
            p1 = i2+(i-1)*k2^(k3-j+1)
            p2 = p1 + k2^(k3-j)
            if (self$binary[p1]!=self$binary[p2]) esen = T
          }
        }
        if (esen==T) ms1=c(ms1,self$ms[j])
      }
      ms1=ms1[-1]
      self$mms=ms1
      return(as.numeric(ms1))
    },

    Table_Minimal_Memory_Set = function(){
      tab1aux=cbind(self$Table_Not_Rule()[,as.character(self$mms)],self$binary)
      tableaux=unique(tab1aux)
      colnames(tableaux)=c(self$mms,"bin")
      return (tableaux)
    },

    CAMapeo = function(Z = NA){
      table = self$Table_Not_Rule()
      Z[is.na(Z)]=0
      for (i in 1:self$nrows){
        flag=T
        for(j in 1:self$ncols){
          if (Z[j]!=table[i,j]) flag=F
        }
        if (flag==T) return (self$binary[i])
      }
      return (self$binary[self$nrows])
    },

    CAEval = function(sucesion = NA){
      NN = length(sucesion)
      ww = self$ms
      while(ww[1]<=0) ww = ww+1
      while(ww[1]>=2) ww = ww-1
      suce2 = rep(-1,NN)
      for (i in seq(0,NN-(self$ms[self$ncols]-self$ms[1])-1,1)){
        suce2[i+1] = self$CAMapeo(sucesion[ww+i])
      }
      return (suce2[suce2>=0])
    },

    Memory_Composition = function(BC = NA){
      S = rep(-1,self$ncols*BC$ncols)
      k=1
      for (i in 1:self$ncols){
        for (j in 1:BC$ncols){
          S[k]=as.numeric(self$ms[i])+as.numeric(BC$ms[j])
          k = k + 1
        }
      }
      return (sort(unique(S)))
    },

    Composition = function(BC = NA){
      SC = self$Memory_Composition(BC)
      BC2 = CA$new(0,ms = SC)
      table=BC2$Table_Not_Rule()

      ac1=BC$CAEval(table[1,1:BC2$ncols])
      for (i in 2:BC2$nrows){
        aux=BC$CAEval(table[i,1:BC2$ncols])
        ac1 = rbind(ac1,aux)
      }

      ac2 = self$CAEval(ac1[1,])
      for (i in 2:BC2$nrows){
        aux=self$CAEval(ac1[i,])
        ac2 = c(ac2,aux)
      }

      mat1=cbind(table,ac2)
      BC2$CAMatrix(mat1)
      return (BC2)
    },

    Reflection = function(){
      tab1 = self$Table_Rule()
      tab2 = tab1
      tab2[,1] = tab1[,3]
      tab2[,3] = tab1[,1]
      tab2 = rbind(tab2[1,],tab2[5,],tab2[3,],tab2[7,],tab2[2,],tab2[6,],tab2[4,],tab2[8,])
      tab1[,4] = tab2[,4]
      AC1 = CA$new(0,A,S)
      AC1$CAMatrix(tab1)
      return (AC1)
    },

    Conjugate = function(){
      tab1 = self$Table_Rule()
      tab2 = tab1
      tab2[tab1==0]=1
      tab2[tab1==1]=0
      tab2 = rbind(tab2[8,],tab2[7,],tab2[6,],tab2[5,],tab2[4,],tab2[3,],tab2[2,],tab2[1,])
      tab1[,4] = tab2[,4]
      AC1 = CA$new(0,A,S)
      AC1$CAMatrix(tab1)
      return (AC1)
    },

    ComplementD = function(){
      tab1 = self$Table_Rule()
      tab2 = tab1
      tab2[tab1==0]=1
      tab2[tab1==1]=0
      tab1[,4] = tab2[,4]
      AC1 = CA$new(0,A,S)
      AC1$CAMatrix(tab1)
      return (AC1)
    },

    ComplementI = function(){
      tab1 = self$Table_Rule()
      tab2 = tab1
      tab2[tab1==0]=1
      tab2[tab1==1]=0
      tab2[,4]=tab1[,4]
      tab2 = rbind(tab2[8,],tab2[7,],tab2[6,],tab2[5,],tab2[4,],tab2[3,],tab2[2,],tab2[1,])
      tab1[,4] = tab2[,4]
      AC1 = CA$new(0,A,S)
      AC1$CAMatrix(tab1)
      return (AC1)
    },

    Classify_Class = function(){
      x=rep(-1,5)
      x[1]=as.numeric(self$decimal)
      x[2]=as.numeric(self$Reflection()$decimal)
      x[3]=as.numeric(self$Conjugate()$decimal)
      x[4]=as.numeric(self$Reflection()$Conjugate()$decimal)
      x[5]=as.numeric(self$ComplementD()$decimal)
      x[6]=as.numeric(self$ComplementI()$decimal)
      x[7]=as.numeric(self$Reflection()$ComplementD()$decimal)
      x[8]=as.numeric(self$Reflection()$ComplementI()$decimal)
      return (min(x))
    }
))
